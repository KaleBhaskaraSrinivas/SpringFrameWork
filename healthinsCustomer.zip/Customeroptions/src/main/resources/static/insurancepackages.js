// Sample JSON data
$.ajax({
	url: "/getInsurancePackages",
	method: "GET",
	success: function(data) {
		console.log(data);
		// Define the Handlebars template
		const cardTemplate = `
    		<div class="card">
        	<h2>{{inspTitle}}</h2>
        	<p>{{inspDesc}}</p>
    		</div>
			`;

		// Compile the template
		const compiledTemplate = Handlebars.compile(cardTemplate);

		// Function to filter and display cards based on the search input
		function filterCards(searchText) {
			const $cardContainer = $('#card-container');
			$cardContainer.empty(); // Clear previous cards

			data.forEach(item => {
				if (item.inspTitle.toLowerCase().includes(searchText.toLowerCase()) || item.inspDesc.toLowerCase().includes(searchText.toLowerCase())) {
					const cardHtml = compiledTemplate(item);
					$cardContainer.append(cardHtml);
				}
			});
		}

		// Initial display of all cards
		filterCards("");

		// Add an event listener to the search input
		$('#search-input').on('input', function() {
			const searchText = $(this).val();
			filterCards(searchText);
		});
	}
});


