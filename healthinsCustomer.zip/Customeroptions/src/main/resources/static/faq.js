$.ajax({
	type: "GET",
	url: "/getFAQS", // Replace with your server endpoint
	success:
		function(faqData) {
			console.log(faqData);
			function populateFAQ() {
				const categories = {};
				// Group FAQ items by category
				faqData.forEach(item => {
					if (!categories[item.category]) {
						categories[item.category] = [];
					}
					categories[item.category].push(item);
				});

				const faqContainer = document.getElementById('faqContainer');

				// Iterate through categories and create collapsible divs
				for (const category in categories) {
					if (categories.hasOwnProperty(category)) {
						const categoryDiv = document.createElement('div');
						categoryDiv.classList.add('category');

						// Category header (collapsible)
						const header = document.createElement('div');
						header.classList.add('category-header');
						header.textContent = category;
						categoryDiv.appendChild(header);

						// Category content (questions and answers)
						const content = document.createElement('div');
						content.classList.add('category-content');

						categories[category].forEach(item => {
							const questionDiv = document.createElement('div');
							questionDiv.classList.add('faq-item');
							questionDiv.innerHTML = `<strong>${item.question}</strong><p>${item.answer}</p>`;
							content.appendChild(questionDiv);
						});

						categoryDiv.appendChild(content);
						faqContainer.appendChild(categoryDiv);

						// Add click event listener to toggle collapsible content
						header.addEventListener('click', () => {
							content.style.display = content.style.display === 'none' ? 'block' : 'none';
						});
					}
				}
			}

			// Function to filter FAQ items based on search input
			function filterFAQ(searchTerm) {
				const faqItems = document.querySelectorAll('.faq-item');
				searchTerm = searchTerm.toLowerCase();

				faqItems.forEach(item => {
					const text = item.textContent.toLowerCase();
					item.style.display = text.includes(searchTerm) ? 'block' : 'none';
				});
			}

			// Initialize the FAQ page
			$(document).ready(function() {
				populateFAQ();

				// Event listener for search input
				$('#searchInput').on('input', function() {
					filterFAQ($(this).val());
				});
			});
		},
	error: function(error) {
		// Handle AJAX request error
		console.error("AJAX Error: " + JSON.stringify(error));
		window.location.href = "home.html";
	}
});


