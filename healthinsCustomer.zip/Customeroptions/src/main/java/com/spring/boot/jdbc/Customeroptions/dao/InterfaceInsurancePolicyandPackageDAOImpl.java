package com.spring.boot.jdbc.Customeroptions.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.spring.boot.jdbc.Customeroptions.contracts.FaqRowMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.InsurancePackagesRowMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.InsurancePolicyMapper;
import com.spring.boot.jdbc.Customeroptions.model.Faq;
import com.spring.boot.jdbc.Customeroptions.model.FormData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePackages;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicy;

@Component
public class InterfaceInsurancePolicyandPackageDAOImpl implements InterfaceInsurancePolicyandPackageDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private String SQL_GET_INSURANCEPOLICIES = "select * from  insurancepolicies";

	private String SQL_GET_CUSTID_INSURANCEPOLICY = "select * from  InsurancePolicy ";

	private String SQL_GET_FAQS = "select * from HealthInsuranceFAQs";

	private String SQL_GET_GFAQS = "select * from HealthInsuranceFAQs where category='General' ";

	private String SQL_GET_CBFAQS = "select * from HealthInsuranceFAQs category='Coverage and Benefits' ";

	private String SQL_GET_INSURANCEPACKAGES = "select * from  InsurancePackages";

	@Override
	public List<InsurancePolicy> getAllInsurancePolicies() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_INSURANCEPOLICIES, new InsurancePolicyMapper());
	}

	@Override
	public List<Faq> getAllFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_FAQS, new FaqRowMapper());
	}

	@Override
	public List<InsurancePolicy> getCustomerInsurancePolicy(int cust) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_CUSTID_INSURANCEPOLICY, new Object[] { cust }, new InsurancePolicyMapper());
	}

	@Override
	public List<InsurancePackages> getInsurancePackages() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_INSURANCEPACKAGES, new InsurancePackagesRowMapper());
	}

	@Override
	public void addCustomer(FormData formData) {
		// TODO Auto-generated method stub
		long aadharLong = 0;
		try {
			String sql = "INSERT INTO customers (cust_fname, cust_lname, cust_dob, cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, cust_luudate, cust_luuser,cust_user_id) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

			String aadharString = formData.getAadhar();
			try {
				aadharLong = Long.parseLong(aadharString);
				// Now 'aadharLong' contains the Aadhar number as a long
			} catch (NumberFormatException e) {
				// Handle the case where 'aadharString' is not a valid long
			}

			// Set values from FormData object
			jdbcTemplate.update(sql, formData.getfName(), formData.getlName(), formData.getDob(), formData.getAddress(),
					formData.getGender(), new Date(), // Assuming cust_cdate is the current date
					aadharLong, "Active", // Assuming cust_status is "Active"
					new Date(), // Assuming cust_luudate is the current date
					1, formData.getId()// Assuming cust_luuser is 1 by default
			);
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}
		try {
			Date currentDate = new Date();

			// Create a calendar instance and set it to the current date
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(currentDate);

			// Add 30 days to the current date
			calendar.add(Calendar.DATE, 30);

			// Get the updated date
			Date updatedDate = calendar.getTime();

			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDate);

			cal.add(Calendar.YEAR, 1);
			Date upDate = cal.getTime();

			String sql = "INSERT INTO insurancepolicies1 (iplc_cust_id,iplc_insp_id, iplc_yrly_prem_amount, iplc_cdate,iplc_applicable_date,iplc_expdate,iplc_agnt_id,iplc_nom_insured,iplc_sum_assured,iplc_paymode_count) "
					+ "VALUES ((select cust_id from customers order by cust_id desc limit 1),?, ?,?,?,?,0,?,?,?)";

			jdbcTemplate.update(sql, formData.getId(), formData.getPrice(), new Date(), updatedDate, upDate,
					formData.getmName().length, formData.getSumassured(), formData.getPaymodecount());
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}

		try {
			String sql = "INSERT INTO insurancepolicycoveragemembers (iplc_id, ipcm_membername, ipcm_relation, ipcm_dob, ipcm_gender, ipcm_healthhistory) "
					+ "VALUES ((select iplc_id from insurancepolicies1 order by  iplc_id desc limit 1),?, ?, ?, ?, ?)";

			for (int i = 0; i < formData.getmName().length; i++) {

				jdbcTemplate.update(sql, formData.getmName()[i], formData.getRelationship()[i], formData.getDob2()[i],
						formData.getGender1()[i], formData.getHealthHistory()[i]

				);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}

	}

	@Override
	public List<Faq> getGeneralFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_GFAQS, new FaqRowMapper());
	}

	@Override
	public List<Faq> getCoverageandBenefitsFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_CBFAQS, new FaqRowMapper());
	}

}
