package com.spring.boot.jdbc.Customeroptions.repository;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.boot.jdbc.Customeroptions.dao.NetworkHospitalDao;
import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;



@Repository
public class NetworkHospitalRepository {
	
	@Autowired
	private NetworkHospitalDao nhdao;
	
	public ArrayList<NetworkHospitals> getAllHospitals(){
		return nhdao.getAllHopitals();
	}

	
}
