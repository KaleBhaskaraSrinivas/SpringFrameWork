package com.spring.boot.jdbc.Customeroptions.dao;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;
import com.spring.boot.jdbc.Customeroptions.contracts.*;


@Component
public class NetworkHospitalDao {
	@Autowired
	JdbcTemplate jdbcTemplate ;
	
	public ArrayList<NetworkHospitals> getAllHopitals(){
		String sql="SELECT * FROM NetworkHospitals";
		
		return (ArrayList<NetworkHospitals>) jdbcTemplate.query(sql, new NetworkHospitalRowMapper());
		
	}

	
	
}
