package com.spring.boot.jdbc.Customeroptions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.jdbc.Customeroptions.model.Faq;
import com.spring.boot.jdbc.Customeroptions.model.FormData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePackages;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicy;
import com.spring.boot.jdbc.Customeroptions.repository.InsurancePackageAndPolicy;

@RestController
public class CustomerController {
	@Autowired(required = true)
	InsurancePackageAndPolicy irrp;

	@GetMapping(value = "/getAllInsurancePolicies")
	public List<InsurancePolicy> getAllInsurancePolicies(Model model) {
		List<InsurancePolicy> li = irrp.getAllInsurancePolicies();
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@GetMapping("/getCustomersInsurancePolicy/{customerId}")
	@ResponseBody
	public List<InsurancePolicy> getCustomerInsurancePolicy(Model model, @PathVariable Integer customerId) {
		List<InsurancePolicy> li = irrp.getCustomerInsurancePolicy(customerId);
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@GetMapping(value = "/getFAQS")
	public List<Faq> getAllFAQS(Model model) {
		List<Faq> li = irrp.getAllFAQS();
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@GetMapping(value = "/getGeneralFAQS")
	public List<Faq> getGeneralFAQS(Model model) {
		System.out.println("varshu2");
		List<Faq> li = irrp.getGeneralFAQS();
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@GetMapping(value = "/getCoverageandBenefitsFAQS")
	public List<Faq> getCoverageandBenefitsFAQS(Model model) {
		System.out.println("varshu2");
		List<Faq> li = irrp.getCoverageandBenefitsFAQS();
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@GetMapping(value = "/html")
	public String gethtml(Model model) {
		return "web";
	}

	@GetMapping(value = "/getInsurancePackages")
	public List<InsurancePackages> getInsurancePackages(Model model) {
		List<InsurancePackages> li = irrp.getInsurancePackages();
		model.addAttribute("list", li);
		System.out.println(li);
		return li;
	}

	@RequestMapping(value = "/applyInsurance", method = RequestMethod.POST)
	public ResponseEntity<Object> createBook(@RequestBody FormData loan) {
		System.out.println(loan.toString());
		irrp.addCustomer(loan);
		return new ResponseEntity<>("Customer is added successfully", HttpStatus.CREATED);
	}

}
