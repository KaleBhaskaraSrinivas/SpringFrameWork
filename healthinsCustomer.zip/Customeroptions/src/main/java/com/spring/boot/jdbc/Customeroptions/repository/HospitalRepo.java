package com.spring.boot.jdbc.Customeroptions.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spring.boot.jdbc.Customeroptions.dao.HospitalDAO;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyPayment;

@Repository
public class HospitalRepo {
	@Autowired
	private HospitalDAO hospitaldao;
	
	
	

	public boolean insertpayment(InsurancePolicyPayment p)
	{
		return hospitaldao.createPayment(p);
	}
	
	public List<InsurancePolicyPayment> getAllIPPsData(){
		List<InsurancePolicyPayment> l1= hospitaldao.getAllInsurancePolicyPaymentsList();
		return l1;
	}
	
	//public object setdataRep(String i) {
	//	return hospitaldao.setdata(i);
		
	//}
	public List<InsurancePolicyPayment> getAllFirstPP(int id) {
		List<InsurancePolicyPayment> l3 = hospitaldao.getAllFirstPolicy(id);
		return l3;
	}

	public boolean updateTransactionsId(int policyId, String newTransactionId, Date currentDate) {
		return hospitaldao.updateTransactionId(policyId, newTransactionId, currentDate);
	}
	
	public List<InsurancePolicyPayment> getAllTransactionsbyID(int custID) {
		List<InsurancePolicyPayment> l3 = hospitaldao.getAllCustPayments(custID);
		return l3;
	}
	
	 public boolean insertIPCMdata(InsurancePolicyCoverageMembers p, int policyid) {
			return hospitaldao.InsertIPCM(p, policyid);
		}


	public List<InsurancePolicyCoverageMembers> getAllIpcmData() {
		List<InsurancePolicyCoverageMembers> l7 = hospitaldao.getAllIPCMList();
		return l7;
	}
}
