package com.spring.boot.jdbc.Customeroptions.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.spring.boot.jdbc.Customeroptions.model.Claim;
import com.spring.boot.jdbc.Customeroptions.model.ClaimApplication;
import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.FamilyMedicalHistoryData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicySchedule;
import com.spring.boot.jdbc.Customeroptions.model.UserData;
import com.spring.boot.jdbc.Customeroptions.model.UserLoginValidation;

public interface InterfaceInsuranceDAO {

	
	int getAllActivecountList();

	List<Integer> getInsurancePremium(int customerId);

	List<Date> getInsuranceDates(int customerId);

	List<Date> getInsuranceEXPDates(int customerId);

	// List<InsurancePolicy> getInsuranceDates(int customerId);

	int getInsuranceSum(int customerId);

	int getInsurancePolicyCountForCustomer(int customerId);

	List<String> getApplicantName(int customerId);

	List<String> getApplicantRelation(int customerId);

	List<InsurancePolicySchedule> getAllSchedule();
	 List<InsurancePolicySchedule> getAllScheduleById(int id);

	long saveUserData(String userName, String password);

	void saveCustomerData(CustomerData customerData);

	void saveFamilyMedicalHistoryData(FamilyMedicalHistoryData history);

	List<CustomerData> getAllCustomersFromDao();

	List<UserData> getAllUsersFromDao();

	List<FamilyMedicalHistoryData> getFamilyMedicalData();

	String uploadFileToDao(MultipartFile file);

	void uploadFileToDatabase(Long userId, Long customerId, String fullPath, String fileName);

	List<String> getPdfFileNames();

	int resetpwd(String email, String pwd);

	void updateCustomersData(List<CustomerData> updatedCustomerData);

	void updateFamilyMedicalHistory(List<FamilyMedicalHistoryData> updatedFamilyMedicalHistoryData);

	int getInsurancePolicyCountForFamily(int customerId);

	public UserLoginValidation getLoginTimeRange(Long userId);
	public Claim getClaimByid(int clamIplcId);
	public void addClaimBills(String originalFilename, String filePath, int cid, int i);
	public void addClaimApplication(ClaimApplication application);
	public void addClaim(int clamIplcId, double claimAmountRequested);
	public ArrayList<Claim> getFilteredClaims(String status);
	public Claim getClaimById(int clamId);
	public ArrayList<Claim> getAllClaims();

}
