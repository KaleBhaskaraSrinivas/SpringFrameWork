package com.spring.boot.jdbc.Customeroptions.dao;


import java.util.ArrayList;
import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;
public interface InterfaceNetworkHospitals {
	ArrayList<NetworkHospitals> getAllHopitals();

}
