package com.spring.boot.jdbc.Customeroptions.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;
import com.spring.boot.jdbc.Customeroptions.repository.NetworkHospitalRepository;


@RestController
public class NetworkHospitalRestController {
	
	@Autowired
	private NetworkHospitalRepository nr;
	
	@GetMapping("/jsonhsp")
	public ArrayList<NetworkHospitals> getAllHospitals() {
		return  nr.getAllHospitals();
		
	}
	

}
