package com.spring.boot.jdbc.Customeroptions.model;
	
	import java.util.Date; // Import for date fields

	public class HealthInsuranceApplication {
	    // Personal Information
	    private String fullName;
	    private String dateOfBirth;
	    private String gender;
	    private String address;
	    private String phoneNumber;
	    private String emailAddress;
	    private String currentEmployer;
	    private String occupation;
	    private double annualIncome;
	    private String parentName;
	    private String spouseName;
	    private String childrenNames;
	    private String medicalHistory;
	    private String previousInsurance;
	    private String familyMedicalHistory;
	    private String smokingStatus;
	    private String alcoholConsumption;
	    private String physicalActivity;
	    private String emergencyContacts;
	    private double householdIncome;
	    
	    

		public HealthInsuranceApplication() {
			super();
			// TODO Auto-generated constructor stub
		}

		public String getFullName() {
			return fullName;
		}


		public void setFullName(String fullName) {
			this.fullName = fullName;
		}




		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getPhoneNumber() {
			return phoneNumber;
		}


		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}


		public String getEmailAddress() {
			return emailAddress;
		}


		public void setEmailAddress(String emailAddress) {
			this.emailAddress = emailAddress;
		}


		public String getCurrentEmployer() {
			return currentEmployer;
		}


		public void setCurrentEmployer(String currentEmployer) {
			this.currentEmployer = currentEmployer;
		}


		public String getOccupation() {
			return occupation;
		}


		public void setOccupation(String occupation) {
			this.occupation = occupation;
		}


		public double getAnnualIncome() {
			return annualIncome;
		}


		public void setAnnualIncome(double annualIncome) {
			this.annualIncome = annualIncome;
		}


		public String getParentName() {
			return parentName;
		}


		public void setParentName(String parentName) {
			this.parentName = parentName;
		}


		public String getSpouseName() {
			return spouseName;
		}


		public void setSpouseName(String spouseName) {
			this.spouseName = spouseName;
		}


		public String getChildrenNames() {
			return childrenNames;
		}


		public void setChildrenNames(String childrenNames) {
			this.childrenNames = childrenNames;
		}


		public String getMedicalHistory() {
			return medicalHistory;
		}


		public void setMedicalHistory(String medicalHistory) {
			this.medicalHistory = medicalHistory;
		}


		public String getPreviousInsurance() {
			return previousInsurance;
		}


		public void setPreviousInsurance(String previousInsurance) {
			this.previousInsurance = previousInsurance;
		}


		public String getFamilyMedicalHistory() {
			return familyMedicalHistory;
		}


		public void setFamilyMedicalHistory(String familyMedicalHistory) {
			this.familyMedicalHistory = familyMedicalHistory;
		}


		public String getSmokingStatus() {
			return smokingStatus;
		}


		public void setSmokingStatus(String smokingStatus) {
			this.smokingStatus = smokingStatus;
		}


		public String getAlcoholConsumption() {
			return alcoholConsumption;
		}


		public void setAlcoholConsumption(String alcoholConsumption) {
			this.alcoholConsumption = alcoholConsumption;
		}


		public String getPhysicalActivity() {
			return physicalActivity;
		}


		public void setPhysicalActivity(String physicalActivity) {
			this.physicalActivity = physicalActivity;
		}


		public String getEmergencyContacts() {
			return emergencyContacts;
		}


		public void setEmergencyContacts(String emergencyContacts) {
			this.emergencyContacts = emergencyContacts;
		}


		public double getHouseholdIncome() {
			return householdIncome;
		}


		public void setHouseholdIncome(double householdIncome) {
			this.householdIncome = householdIncome;
		}


		
		@Override
		public String toString() {
			return "HealthInsuranceApplication [fullName=" + fullName + ", dateOfBirth=" + dateOfBirth + ", gender="
					+ gender + ", address=" + address + ", phoneNumber=" + phoneNumber + ", emailAddress="
					+ emailAddress + ", currentEmployer=" + currentEmployer + ", occupation=" + occupation
					+ ", annualIncome=" + annualIncome + ", parentName=" + parentName + ", spouseName=" + spouseName
					+ ", childrenNames=" + childrenNames + ", medicalHistory=" + medicalHistory + ", previousInsurance="
					+ previousInsurance + ", familyMedicalHistory=" + familyMedicalHistory + ", smokingStatus="
					+ smokingStatus + ", alcoholConsumption=" + alcoholConsumption + ", physicalActivity="
					+ physicalActivity + ", emergencyContacts=" + emergencyContacts + ", householdIncome="
					+ householdIncome + ", getFullName()=" + getFullName() + ", getDateOfBirth()=" + getDateOfBirth()
					+ ", getGender()=" + getGender() + ", getAddress()=" + getAddress() + ", getPhoneNumber()="
					+ getPhoneNumber() + ", getEmailAddress()=" + getEmailAddress() + ", getCurrentEmployer()="
					+ getCurrentEmployer() + ", getOccupation()=" + getOccupation() + ", getAnnualIncome()="
					+ getAnnualIncome() + ", getParentName()=" + getParentName() + ", getSpouseName()="
					+ getSpouseName() + ", getChildrenNames()=" + getChildrenNames() + ", getMedicalHistory()="
					+ getMedicalHistory() + ", getPreviousInsurance()=" + getPreviousInsurance()
					+ ", getFamilyMedicalHistory()=" + getFamilyMedicalHistory() + ", getSmokingStatus()="
					+ getSmokingStatus() + ", getAlcoholConsumption()=" + getAlcoholConsumption()
					+ ", getPhysicalActivity()=" + getPhysicalActivity() + ", getEmergencyContacts()="
					+ getEmergencyContacts() + ", getHouseholdIncome()=" + getHouseholdIncome() + ", getClass()="
					+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}

		public String getDateOfBirth() {
			return dateOfBirth;
		}

		public void setDateOfBirth(String dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

	

	    
	}


	   
