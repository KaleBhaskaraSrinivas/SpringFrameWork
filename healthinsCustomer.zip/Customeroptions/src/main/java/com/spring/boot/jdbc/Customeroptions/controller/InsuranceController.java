package com.spring.boot.jdbc.Customeroptions.controller;

import com.spring.boot.jdbc.Customeroptions.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spring.boot.jdbc.Customeroptions.repository.InsuranceRepository;

import jakarta.servlet.http.HttpSession;

@RestController
public class InsuranceController {
	InsuranceRepository insuranceres;
	private HttpSession session;

	List<UserData> UserDataList;

	@Autowired
	public InsuranceController(InsuranceRepository insuranceres, HttpSession httpSession) {

		this.insuranceres = insuranceres;
		this.session = httpSession;
	}

	@GetMapping("/getActive")
	public int getActive() {
		int hospitals = insuranceres.getAllActivecount();
		return hospitals;

	}

	@GetMapping("/policy/{customerId}")
	public int getInsurancePolicyCount(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicyCountForCustomer(customerId);
		return policyCount;
	}

	@GetMapping("/policyFam/{customerId}")
	public int getInsuranceFamilyCount(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicyCountForFamily(customerId);
		return policyCount;
	}

	@GetMapping("/policySum/{customerId}")
	public int getInsurancePolicySum(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicySum(customerId);
		return policyCount;
	}

	@GetMapping("/policyDates/{customerId}")
	public List<Date> getInsurancePolicyDate(@PathVariable int customerId) {
		List<Date> policyCount = insuranceres.getAllInsuranceDates(customerId);
		return policyCount;
	}

	@GetMapping("/policyEXPDates/{customerId}")
	public List<Date> getInsurancePolicyEXPDate(@PathVariable int customerId) {
		List<Date> policyCount = insuranceres.getAllInsuranceEXPDates(customerId);
		return policyCount;
	}

	@GetMapping("/policyPremAmount/{customerId}")
	public List<Integer> getInsurancePremiumMount(@PathVariable int customerId) {
		List<Integer> policyCount = insuranceres.getInsurancePremiumAmount(customerId);
		return policyCount;
	}

	@GetMapping("/policyPremRealtion/{customerId}")
	public List<String> getInsuranceAppRelation(@PathVariable int customerId) {
		List<String> policyCount = insuranceres.getApplicantRelation(customerId);
		return policyCount;
	}

	@GetMapping("/policySchedule")
	public List<InsurancePolicySchedule> getAllPolicySchedule() {
		return insuranceres.ListAllPolicySchedules();
	}

	@GetMapping("/policySchedule/{id}")
	public List<InsurancePolicySchedule> listAllPolicySchedules(@PathVariable Integer id) {
		return insuranceres.ListAllPolicySchedulesById(id);
	}

	@PostMapping("/saveUserData")
	@ResponseBody
	public Long saveUserData(@RequestParam("username") String userName, @RequestParam("password") String password) {
		return insuranceres.saveUserData(userName, password);

	}

	@PostMapping("/saveCustomerData")
	@ResponseBody
	public String saveCustomerData(@RequestBody CustomerData customerData) {
		customerData.setCust_status("Active");
		// Set the last updated date and user
		customerData.setCust_luudate(new Date(Calendar.getInstance().getTime().getTime())); // Current timestamp
		customerData.setCust_luuser(1);
		customerData.setCust_user_id((long) session.getAttribute("userId"));
		// Set a default value for cust_cdate (assuming it's a Date field)
		customerData.setCust_cdate(new Date(Calendar.getInstance().getTime().getTime())); // Current timestamp
		System.out.println("Received customer data: " + customerData);
		insuranceres.saveCustomerData(customerData);
		return "Customer data saved successfully";
	}

	@PostMapping("/saveFamilyMedicalHistory")
	public String saveFamilyMedicalHistory(@RequestBody FamilyMedicalHistoryData data) {

		insuranceres.saveFamilyMedicalHistory(data);
		return "succesfuly saved";

	}

	@RequestMapping(value = "/Customers", method = RequestMethod.GET)

	public List<CustomerData> getAllCustomers() {
		Long id = (Long) session.getAttribute("userId");
		System.out.println("customers");
		return insuranceres.getAllCustomers();
	}

	@RequestMapping(value = "/UpdateCustomers", method = RequestMethod.POST)

	public String UpdateCustomers(@RequestBody List<CustomerData> updatedCustomerData) {

		for (CustomerData customerData : updatedCustomerData) {
			customerData.setCust_status("Active");

			// Convert java.util.Date to java.sql.Date
			java.util.Date now = new java.util.Date();
			customerData.setCust_luudate(new Date(now.getTime()));
			customerData.setCust_luuser(1);

			// Set a default value for cust_cdate as SQL Date (assuming it's a Date field)
			customerData.setCust_cdate(new Date(now.getTime()));

		}

		String check = insuranceres.updateCustomersData(updatedCustomerData);

		return check;
	}

	@RequestMapping(value = "/UpdateFamilyMedicalHistory", method = RequestMethod.POST)

	public String UpdateFamilyMedicalHistory(
			@RequestBody List<FamilyMedicalHistoryData> UpdatedFamilyMedicalHistoryData) {

		String check = insuranceres.UpdateFamilyMedicalHistory(UpdatedFamilyMedicalHistoryData);

		return check;
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public List<UserData> getAllUsers() {

		System.out.println("users");

		UserDataList = insuranceres.getAllUsers();

		return UserDataList;
	}

	@RequestMapping(value = "/UserLogin", method = RequestMethod.POST)

	public String userCredinitial(@RequestParam("username") String userName,
			@RequestParam("password") String password) {

		UserDataList = insuranceres.getAllUsers();
		boolean b = insuranceres.userChecking(userName, password, UserDataList);
		if (b) {
			return "1";
		}

		System.out.println("customers");

		return "-1";
	}

	@RequestMapping(value = "/FamilyMedicalData", method = RequestMethod.GET)
	public List<FamilyMedicalHistoryData> getFamilyMedicalData() {

		System.out.println("medical");

		return insuranceres.getFamilyMedicalData();

	}

	@PostMapping("/uploadDocument")
	public ResponseEntity<String> uploadDocument(@RequestParam("file") MultipartFile file,
			@RequestParam("customerId") Long id, @RequestParam("userId") Long userId) {
		try {
			// Validate and process the uploaded file
			if (file.isEmpty()) {
				return new ResponseEntity<>("File is empty", HttpStatus.BAD_REQUEST);
			}

			String fileName = insuranceres.uploadFile(file); // Implement this method
			session.setAttribute("custId", id);

			// You can return a success message or the file name
			return new ResponseEntity<>("File uploaded successfully. File name: " + fileName, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>("Error uploading file: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Value("${pdfFilesPath}") // Replace with the actual path to your PDF files
	private String pdfFilesPath;

	@RequestMapping(value = "/list-pdf-files", method = RequestMethod.GET)
	public List<String> listPdfFiles(Model model) {
		// Use pdfFilesPath to construct the full path to your PDF files
		String fullPath = pdfFilesPath + "/"; // Add a slash to separate the base path from the filenames

		// Implement logic to get a list of PDF file names from your repository
		// For this example, we'll assume you have a method getPdfFileNames that returns
		// a list of filenames
		List<String> pdfFileNames = insuranceres.getPdfFileNames();

		List<String> pdfFileUrls = new ArrayList<>();
		for (String fileName : pdfFileNames) {
			// Create the PDF file URL based on the full path and file name
			String pdfFileUrl = fullPath + fileName;
			pdfFileUrls.add(pdfFileUrl);
		}

		return pdfFileUrls; // This should be the name of your HTML template
	}

	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {
		String email = to_mail;
		session.setAttribute("email", email);
		// storing generated otp
		int OTP = insuranceres.sendmail(to_mail);
		System.out.println(to_mail + "email here");
		System.out.println(OTP + "otp here");

		LocalTime currentTime = LocalTime.now();
		session.setAttribute("time", currentTime.plusMinutes(5));
		session.setAttribute("OTP", OTP);

		return "Email Sent Successfully";

	}

	@PostMapping(value = "/validateOTP")
	public String validateOTP(@RequestParam("otp") String otp, Model model) {
		model.addAttribute("to", "");
		int OTP = Integer.parseInt(otp);
		ModelAndView mav = new ModelAndView();
		int originalOtp = (Integer) session.getAttribute("OTP");
		String email = (String) session.getAttribute("email");

		LocalTime time = (LocalTime) session.getAttribute("time");
		int comp = time.compareTo(LocalTime.now());
		// checking the otp sent by the user if true returning reset page else need to
		// stay in the same page with error
		// msg
		if (originalOtp == OTP && comp > 0) {
			mav.setViewName("reset");
			mav.addObject("email", email);
			return "otp Match";
		}
		if (comp < 0)
			return "OTP expired, please try again..";
		else
			return "Invalid OTP, please try again..";

	}

	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		System.out.println(email + " " + pwd + " " + cnfpwd);
		int x = insuranceres.resetpwd(email, pwd, cnfpwd);
		if (x > 0)
			return "password Changed";
		else
			return "pasword not match";

	}
	@RequestMapping(value = "/claimbills", method = RequestMethod.POST)
	public String claimData(@RequestParam("file[]") MultipartFile[] files,@RequestParam("claimAmount[]") int[] amount, Claim claim, ClaimApplication application,
			Model model) {

		insuranceres.addClaimApplication(application);
		insuranceres.addClaim(claim.getClamIplcId(),application.getClaimAmountRequested());
		Claim clm_id = insuranceres.getClaimByid(claim.getClamIplcId());
		int cid = clm_id.getClamId();
		String uploadDir = "src/main/resources/static/file";
		int i=0;
		try {
			// Create the target directory if it doesn't exist
			Files.createDirectories(Paths.get(uploadDir));

			for (MultipartFile file : files) {
				// Get the original file name
				String fileName = StringUtils.cleanPath(file.getOriginalFilename());

				// Create the target file path within the directory
				Path targetLocation = Paths.get(uploadDir).resolve(fileName);

				// Copy the file to the target location
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

				String fn="file/"+file.getOriginalFilename();
				
				
				System.out.println("original file name..."+file.getOriginalFilename());
				System.out.println("file path..."+fn);
				

				insuranceres.addClaimBills(file.getOriginalFilename(), fn, cid,amount[i]);
				i++;

			}

			// After successfully storing all files, you can redirect to a success page or return a response accordingly
			return "SETCLAIMS";
		} catch (IOException ex) {
			ex.printStackTrace();

		}

		return "SETCLAIMS";
	}
	
	@GetMapping(value = "/viewClaim")
	public Claim getClaimById(Model model, @RequestParam("clamId") int clamId) {
		Claim cl = insuranceres.getClaimById(clamId);
		model.addAttribute("claim", cl);
		return cl;
	}

	@GetMapping(value = "/getFilteredClaims")
	public ArrayList<Claim> getFilteredClaims(Model model, @RequestParam("status") String status) {
		ArrayList<Claim> li = (ArrayList<Claim>) insuranceres.getFilteredClaims(status);
		System.out.println(li.size());
		model.addAttribute("claims", li);
		return li;
	}
	@GetMapping(value = "/getAllClaims")
	public ArrayList<Claim> getAllClaims(Model model) {
		ArrayList<Claim> li = (ArrayList<Claim>) insuranceres.getAllClaims();
		System.out.println(li.size());
		model.addAttribute("claims", li);
		return li;
	}



}
