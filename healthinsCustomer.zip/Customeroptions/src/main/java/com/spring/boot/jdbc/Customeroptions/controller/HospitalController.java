package com.spring.boot.jdbc.Customeroptions.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyPayment;
import com.spring.boot.jdbc.Customeroptions.repository.HospitalRepo;

@RestController
public class HospitalController {

	@Autowired
	HospitalRepo hospitalres;

	@PostMapping("/create")
	public ResponseEntity<String> createPayment(@RequestBody InsurancePolicyPayment payment) {
		try {
			boolean result = hospitalres.insertpayment(payment);
			if (result) {
				return ResponseEntity.ok("Payment created successfully");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create payment");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create payment");
		}
	}

	@GetMapping(value = "/ipps")
	public List<InsurancePolicyPayment> getAllpps() {

		List<InsurancePolicyPayment> hosp = hospitalres.getAllIPPsData();
		return hosp;
	}

	@GetMapping(value = "/ipps/{iplc_id}")
	public List<InsurancePolicyPayment> getAllFirstPP(@PathVariable int iplc_id) {

		List<InsurancePolicyPayment> hosp = hospitalres.getAllFirstPP(iplc_id);
		return hosp;
	}

	@GetMapping(value = "/ippsts/{cust_id}")
	public List<InsurancePolicyPayment> getAlltransactionsbycustid(@PathVariable int cust_id) {

		List<InsurancePolicyPayment> hosp = hospitalres.getAllTransactionsbyID(cust_id);
		return hosp;
	}

	@PostMapping("/updatePayment")
	public ResponseEntity<String> updatePaymentRecord(@RequestBody Map<String, String> requestData)
			throws ParseException {
		System.out.println(requestData);
		String policyIdStr = requestData.get("policyId");
		String transactionId = requestData.get("transactionId");
		String transDateStr = requestData.get("transDate");
		if (transDateStr == null || transDateStr.isEmpty()) {
			return ResponseEntity.badRequest().body("currentDate is missing or empty.");
		}

		try {
			int policyId = Integer.parseInt(policyIdStr);

			// Parse currentDateStr into a Date object (assuming it's in ISO format)
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date transDate = dateFormat.parse(transDateStr);

			// Convert java.util.Date to java.sql.Date
			java.sql.Date sqlTransDate = new java.sql.Date(transDate.getTime());
			// LocalDate currentDate = LocalDate.now();

			// Call the updateTransactionId method from the repository with java.sql.Date
			boolean updateSuccess = hospitalres.updateTransactionsId(policyId, transactionId, sqlTransDate);

			if (updateSuccess) {
				return ResponseEntity.ok("Payment record updated successfully.");
			} else {
				return ResponseEntity.badRequest().body("Failed to update payment record.");
			}
		} catch (NumberFormatException e) {
			return ResponseEntity.badRequest().body("Invalid policyId provided.");
		}
	}

	@PostMapping("/insertipcm/{policyid}")
	public ResponseEntity<String> Insert(@RequestBody InsurancePolicyCoverageMembers ipcm, @PathVariable int policyid) {
		try {
			boolean result = hospitalres.insertIPCMdata(ipcm, policyid);
			if (result) {
				return ResponseEntity.ok("InsurancePolicyCoverageMember created successfully");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create member");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create member");
		}
	}

	@GetMapping(value = "/ipcmsdata")
	public List<InsurancePolicyCoverageMembers> getAlldata() {

		List<InsurancePolicyCoverageMembers> hosp = hospitalres.getAllIpcmData();
		return hosp;

	}

}
