/**
 * 
 */
package com.mymeal.services;

import java.util.List;

import com.mymeal.models.MenuItems;

/**
 * @author bharadwaj.b
 *
 */
public interface MealListService {

	public List<MenuItems> getMenuItems();

}
