package com.mymeal.services;

import java.util.Properties;
import java.util.Random;
import java.util.UUID;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mymeal.daos.UserDAO;
import com.mymeal.models.User;

import jakarta.servlet.http.HttpSession;

@Service
public class LoginServiceImpl implements LoginService {
	public UserDAO usrDAO;
	HttpSession session;

	@Autowired
	public LoginServiceImpl(UserDAO userDAO, HttpSession session) {
		this.usrDAO = userDAO;
		this.session = session;
	}

	@Override
	public boolean checkUserCredentials(String empId, String password) {
		boolean b = usrDAO.checkUserCredentials(empId, password);

		return b;
	}

	@Override
	public boolean registerUser(User user) {
		boolean b = usrDAO.registerUser(user);
		return b;
	}

	@Override
	public String generateRandomToken() {
		return UUID.randomUUID().toString();
	}

	@Override
	public boolean saveRandomstring(String empId, String ran) {
		return usrDAO.saveRandomstring(empId, ran);

	}

	@Override
	public boolean saveEmployeeRole(String empId) {
		return usrDAO.saveEmployeeRole(empId);
	}

	@Override
	public String getRoleById(String empId) {
		return usrDAO.getRoleById(empId);
		
	}

	@Override
	public int sendmail(String to_mail) {
		String to = to_mail;
		String subject = "Login OTP";

		int OTP = generateOTP();
		String body = "Your OTP for login : " + OTP;
		sendEmail(to, subject, body);

		return OTP;
	}

	// Method to send an email
	@Override
	public void sendEmail(String to, String subject, String body) {
		String host = "smtp.gmail.com";
		int port = 587;
		String username = "otp.health.insurance@gmail.com";
		String password = "zveu kbpc ivrp fenc";

		// Set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);

		// Create session
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// Create message
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);
			message.setText(body);
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	// Method to generate a random OTP
	@Override
	public int generateOTP() {
		Random random = new Random();
		int randomNumber = 100000 + random.nextInt(900000);

		return randomNumber;
	}
	
	
	@Override
	public int resetpwd(String email, String pwd, String cnfpwd, String empId) {
		if (pwd.equals(cnfpwd))
			return usrDAO.resetpwd(email, pwd, empId);
		else
			return 0;
	}


	


}
