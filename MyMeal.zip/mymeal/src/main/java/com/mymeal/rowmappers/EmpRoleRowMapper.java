package com.mymeal.rowmappers;
import org.springframework.jdbc.core.RowMapper;

import com.mymeal.models.EmpRole;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpRoleRowMapper implements RowMapper<EmpRole> {

    @Override
    public EmpRole mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        EmpRole empRole = new EmpRole();
        empRole.setEmpId(resultSet.getString("empId"));
        empRole.setRole(resultSet.getString("role"));
        return empRole;
    }
}
