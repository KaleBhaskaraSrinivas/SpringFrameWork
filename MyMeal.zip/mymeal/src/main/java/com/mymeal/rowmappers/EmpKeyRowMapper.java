package com.mymeal.rowmappers;
import org.springframework.jdbc.core.RowMapper;

import com.mymeal.models.EmpKey;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpKeyRowMapper implements RowMapper<EmpKey> {

    @Override
    public EmpKey mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        EmpKey empKey = new EmpKey();
        empKey.setEmpId(resultSet.getString("empId"));
        empKey.setKey(resultSet.getString("key"));
        return empKey;
    }
}
