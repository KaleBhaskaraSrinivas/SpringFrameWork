package com.mymeal.daos;

import com.mymeal.models.User;

public interface UserDAO {


	public boolean checkUserCredentials(String empId, String password);

	public boolean registerUser(User user);

	public boolean saveRandomstring(String empId, String random);
	
	public boolean saveEmployeeRole(String empId);
	
	public String getRoleById(String empId);
	
	public int resetpwd(String email, String pwd, java.lang.String empId);

}
