package com.mymeal.models;
public class EmpRole {

    private String empId; // Assuming empId is the primary key
    private String role;

    // Constructors, getters, and setters

    public EmpRole() {
        // Default constructor
    }

    public EmpRole(String empId, String role) {
        this.empId = empId;
        this.role = role;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
