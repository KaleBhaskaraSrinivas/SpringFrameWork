package com.mymeal.models;

public class User {

	private int id; // Assuming you have an ID for the user, adjust as needed

	private String username;

	private String email;

	private String employeeid;

	private String phoneNo;

	private String password;

	private String repeatPassword;

	// Constructors, getters, and setters

	public User() {
		// Default constructor
	}

	public User(String username, String email, String employeeid, String phoneNo, String password,
			String repeatPassword) {
		this.username = username;
		this.email = email;
		this.employeeid = employeeid;
		this.phoneNo = phoneNo;
		this.password = password;
		this.repeatPassword = repeatPassword;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepeatPassword() {
		return repeatPassword;
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", email=" + email + ", employeeid=" + employeeid
				+ ", phoneNo=" + phoneNo + ", password=" + password + ", repeatPassword=" + repeatPassword + "]";
	}

}
