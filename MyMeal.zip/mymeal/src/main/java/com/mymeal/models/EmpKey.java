package com.mymeal.models;
public class EmpKey {

    private String empId;
    private String key;

    // Constructors, getters, and setters

    public EmpKey() {
        // Default constructor
    }

    public EmpKey(String empId, String key) {
        this.empId = empId;
        this.key = key;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
