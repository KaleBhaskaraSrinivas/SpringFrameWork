var url = "/customer/getrequired?claimid=";
var claimid = 20;

url += claimid;

$.ajax({
	url: url,
	success: function(jsonData){
	
		console.log(jsonData);
		
        // Function to create card for each item
        function createCard(item) {
            var cardContainer = $('#cardContainer');

            // Create card
            var card = $('<div>').addClass('card');

            // Create card body
            var cardBody = $('<div>').addClass('card-body');

            // Create card title (assuming name is used as the title)
            var cardTitle = $('<h5>').addClass('card-title').text(item.name);

            // Create input field
            var inputField = $('<input>')
                .attr('type', item.type)
                .attr('name', item.name)
                .addClass('form-control');

            // Create card text (assuming description is used as the text)
            var cardText = $('<p>').addClass('card-text').text(item.description);

            // Append elements to the card body
            cardBody.append(cardTitle);
            cardBody.append(inputField);
            cardBody.append(cardText);

            // Append card body to the card
            card.append(cardBody);

            // Append card to the card container
            cardContainer.append(card);
        }

        // Loop through JSON data and create a card for each item
        jsonData.forEach(function(item) {
            createCard(item);
        });
 
	},
	error: function(error){
		console.log(error);
	}
});


$("#submitButton").click(function () {
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "/customer/adduploads",
            contentType: "multipart/form-data",
            params: {'claimid' : 20},
            data: formData,
            contentType: "application/json;charset=UTF-8",
            success: function (response) {
            	console.log(1);
            }
        });
    });
