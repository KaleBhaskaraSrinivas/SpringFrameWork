// Function to enable/disable form inputs for Address and Last Name
function toggleFormInputs(enable) {
  const addressInput = document.getElementById('address');
  const lastNameInput = document.getElementById('lastName');

  addressInput.disabled = !enable;
  lastNameInput.disabled = !enable;
}

// Function to handle Edit Profile button click
document.getElementById('editProfileBtn').addEventListener('click', function() {
  toggleFormInputs(true);
  document.getElementById('saveProfileBtn').style.display = 'block';
  this.style.display = 'none';
});

// Function to handle form submission (Save Profile)
document.getElementById('profileForm').addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent default form submission behavior

  // Implement validation here, e.g., check if the inputs are valid

  // If validation passes, you can save the changes
  toggleFormInputs(false);
  document.getElementById('editProfileBtn').style.display = 'block';
  document.getElementById('saveProfileBtn').style.display = 'none';
});
