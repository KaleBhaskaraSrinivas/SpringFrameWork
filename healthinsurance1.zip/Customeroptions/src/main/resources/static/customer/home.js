document.getElementById('last-premium-invoice').addEventListener('click', function() {
  // Get the content of the div
  const content = document.getElementById('last-premium-details').innerText;

  // Create the PDF document definition
  const pdfDefinition = {
    content: [
      { text: "Premium Payment Invoice", style: "header" },
      { text: content }
    ],
    styles: {
      header: {
        fontSize: 18,
        bold: true,
        margin: [0, 0, 0, 10]
      }
    }
  };

  // Generate and download the PDF
  pdfMake.createPdf(pdfDefinition).download('invoice.pdf');
});

document.getElementById('pay-premium-now').onclick = function() {

  var amount = parseFloat(1000);

  var options = {
    "key": "rzp_test_ep0Ba9QlOmhL7w",
    "amount": amount * 100, // Amount in paise (100 paise = 1 INR)
    "currency": "INR",
    "handler": function(response) {
      console.log(response.razorpay_payment_id);
    },
  };

  var rzp1 = new Razorpay(options);
  rzp1.open();
}

document.getElementById("view-premium-schedule").addEventListener('click',function(){
	window.location.href = "policyschedule.html"
});

document.getElementById("view-past-bills").addEventListener('click',function(){
	window.location.href = "paymenthistory.html"
});

document.getElementById("buy-new").addEventListener('click',function(){
	window.location.href = "applynew.html"
});

document.getElementById("view-packages").addEventListener('click',function(){
	window.location.href = "insurancepackages.html"
});