package com.spring.boot.jdbc.Customeroptions.contracts;

import org.springframework.jdbc.core.RowMapper;

import com.spring.boot.jdbc.Customeroptions.model.Faq;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FaqRowMapper implements RowMapper<Faq> {

	@Override
	public Faq mapRow(ResultSet rs, int rowNum) throws SQLException {
		Faq faq = new Faq();
        faq.setId(rs.getLong("id"));
        faq.setQuestion(rs.getString("question"));
        faq.setAnswer(rs.getString("answer"));
        faq.setCategory(rs.getString("category"));
        return faq;
		
	}
}
