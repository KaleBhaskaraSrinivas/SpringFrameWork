package com.spring.boot.jdbc.Customeroptions.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyPayment;
import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;

public interface HospitalIntDAO {

	public boolean createPayment(InsurancePolicyPayment ipp);

	List<InsurancePolicyPayment> getAllInsurancePolicyPaymentsList();

  	boolean updateTransactionId(int policyId, String newTransactionId, Date transdate);

	List<InsurancePolicyPayment> getAllFirstPolicy(int policyId);

	List<InsurancePolicyPayment> getAllCustPayments(int custId);

	List<InsurancePolicyCoverageMembers> getAllIPCMList();

	public boolean InsertIPCM(InsurancePolicyCoverageMembers ipcm, int policyid);
	ArrayList<NetworkHospitals> getAllHopitals();
	

}
