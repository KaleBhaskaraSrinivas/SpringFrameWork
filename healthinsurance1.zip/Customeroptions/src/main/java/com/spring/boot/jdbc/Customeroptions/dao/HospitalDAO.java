package com.spring.boot.jdbc.Customeroptions.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.spring.boot.jdbc.Customeroptions.contracts.*;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyPayment;
import com.spring.boot.jdbc.Customeroptions.model.NetworkHospitals;

@Component
public class HospitalDAO implements HospitalIntDAO {
	JdbcTemplate jdbcTemplate;

	@Autowired
	public HospitalDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private final String SQL_DISPLAY_NetworkHospitals = "SELECT * FROM NetworkHospitals";
	private final String SQL_DISPLAY_insurancepayments = "SELECT * FROM InsurancePolicyPayments";

	private final String SQL_DISPLAY_NETWORKHOSPITALSBYCITY = "SELECT * FROM NetworkHospitals WHERE hosp_city = ?";
	private final String SQL_DISPLAY_BYCITY = "SELECT * FROM NetworkHospitals WHERE hosp_grade = ?";
	private final String SQL_DISPLAY_FACILITY = "SELECT * FROM NetworkHospitals WHERE hosp_facility = ?";
	private final String SQL_DISPLAY_ID = "SELECT * FROM NetworkHospitals WHERE hosp_id = ?";
	private final String SQL_INSERT_PAYMENT = "INSERT INTO InsurancePolicyPayments (inpp_iplc_id, inpp_trans_id, inpp_amount, inpp_paymode,inpp_date) VALUES (?,?, ?, ?, ?,?)";

	private final String SQL_UPDATE_TRANSACTIONID = "UPDATE InsurancePolicyPayments\r\n"
			+ "	SET inpp_trans_id = ?, inpp_date = ?\r\n"
			+ "	WHERE inpp_iplc_id = ? \r\n"
			+ "	  AND inpp_trans_id IS NULL \r\n"
			+ "	  AND inpp_date IS NULL \r\n"
			+ "	  AND iplc_sindex = (\r\n"
			+ "	    SELECT MIN(iplc_sindex) \r\n"
			+ "	    FROM InsurancePolicyPayments \r\n"
			+ "	    WHERE inpp_iplc_id = ?\r\n"
			+ "	      AND inpp_trans_id IS NULL \r\n"
			+ "	      AND inpp_date IS NULL\r\n"
			+ "	  )";	  
	private final String SQL_DISPLAY_FIRSTPP = "SELECT * FROM InsurancePolicyPayments WHERE inpp_iplc_id = ? LIMIT 1";

	private final String SQL_DISPLAY_TRANSACTIONSBYCUSTID="SELECT\r\n"
			+ "    IPP.inpp_id,\r\n"
			+ "    IPP.inpp_iplc_id,\r\n"
			+ "    IPP.inpp_trans_id,\r\n"
			+ "    IPP.inpp_amount,\r\n"
			+ "    IPP.inpp_paymode,\r\n"
			+ "    IPP.inpp_date\r\n"
			+ "FROM\r\n"
			+ "    InsurancePolicyPayments AS IPP\r\n"
			+ "WHERE\r\n"
			+ "    IPP.inpp_iplc_id IN (\r\n"
			+ "        SELECT iplc_id\r\n"
			+ "        FROM InsurancePolicies1\r\n"
			+ "        WHERE iplc_cust_id = ?\r\n"
			+ "    );\r\n";

	private String SQL_INSERT_MEMBER = "INSERT INTO InsurancePolicyCoverageMembers (iplc_id, ipcm_membername, ipcm_relation, ipcm_dob, ipcm_gender, ipcm_healthhistory) SELECT p.iplc_id, ?, ?, ?, ?, ? FROM InsurancePolicies1 p WHERE p.iplc_id = ?";

	private final String SQL_DISPLAY_IPCMLISTS = "SELECT * FROM InsurancePolicyCoverageMembers";

	@Override
	public boolean createPayment(InsurancePolicyPayment payment) {
		return jdbcTemplate.update(SQL_INSERT_PAYMENT, payment.getPolicyId(), payment.getTransactionId(),
				payment.getAmount(), payment.getPaymentMode(),payment.getTransDate()) > 0;
	}

	@Override
	public List<InsurancePolicyPayment> getAllInsurancePolicyPaymentsList() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_DISPLAY_insurancepayments, new InsurancePolicyPaymentMapper());

	}

	@Override
	public List<InsurancePolicyPayment> getAllFirstPolicy(int policyId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_DISPLAY_FIRSTPP, new InsurancePolicyPaymentMapper(), policyId);

	}

	@Override
	public boolean updateTransactionId(int policyId, String newTransactionId, Date transdate) {
		return jdbcTemplate.update(SQL_UPDATE_TRANSACTIONID, newTransactionId, transdate, policyId,policyId) > 0;
	}
  

	@Override
	public List<InsurancePolicyPayment> getAllCustPayments(int custId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_DISPLAY_TRANSACTIONSBYCUSTID, new InsurancePolicyPaymentMapper(), custId);

	}

	@Override
	public boolean InsertIPCM(InsurancePolicyCoverageMembers ipcm, int policyid) {
		return jdbcTemplate.update(SQL_INSERT_MEMBER, ipcm.getIpcmMemberName(), ipcm.getIpcmRelation(),
				ipcm.getIpcmDob(), ipcm.getIpcmGender(), ipcm.getIpcmHealthHistory(), policyid) > 0;
	}

	@Override
	public List<InsurancePolicyCoverageMembers> getAllIPCMList() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_DISPLAY_IPCMLISTS, new InsurancePolicyCoverageMemberMapper());
	}
	public ArrayList<NetworkHospitals> getAllHopitals(){
		String sql="SELECT * FROM NetworkHospitals";
		
		return (ArrayList<NetworkHospitals>) jdbcTemplate.query(sql, new NetworkHospitalRowMapper());
		
	}
}
