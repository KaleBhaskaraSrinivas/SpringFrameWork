package com.spring.boot.jdbc.Customeroptions.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.spring.boot.jdbc.Customeroptions.model.Claim;
import com.spring.boot.jdbc.Customeroptions.model.ClaimApplication;
import com.spring.boot.jdbc.Customeroptions.model.ClaimBills;
import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicySchedule;
import com.spring.boot.jdbc.Customeroptions.model.ReUpload;
import com.spring.boot.jdbc.Customeroptions.model.Uploads;
import com.spring.boot.jdbc.Customeroptions.model.UserData;
import com.spring.boot.jdbc.Customeroptions.repository.InsuranceRepository;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/customer")
public class InsuranceController {
	InsuranceRepository insuranceres;
	private HttpSession session;

	List<UserData> UserDataList;

	@Autowired
	public InsuranceController(InsuranceRepository insuranceres, HttpSession httpSession) {
		this.insuranceres = insuranceres;
		this.session = httpSession;
	}

	@GetMapping("/getActive")
	public int getActive() {
		int hospitals = insuranceres.getAllActivecount();
		return hospitals;

	}

	@GetMapping("/policy/{customerId}")
	public int getInsurancePolicyCount(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicyCountForCustomer(customerId);
		return policyCount;
	}

	@GetMapping("/policyFam/{customerId}")
	public int getInsuranceFamilyCount(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicyCountForFamily(customerId);
		return policyCount;
	}

	@GetMapping("/policySum/{customerId}")
	public int getInsurancePolicySum(@PathVariable int customerId) {
		int policyCount = insuranceres.getInsurancePolicySum(customerId);
		return policyCount;
	}

	@GetMapping("/policyDates/{customerId}")
	public List<Date> getInsurancePolicyDate(@PathVariable int customerId) {
		List<Date> policyCount = insuranceres.getAllInsuranceDates(customerId);
		return policyCount;
	}

	@GetMapping("/policyEXPDates/{customerId}")
	public List<Date> getInsurancePolicyEXPDate(@PathVariable int customerId) {
		List<Date> policyCount = insuranceres.getAllInsuranceEXPDates(customerId);
		return policyCount;
	}

	@GetMapping("/policyPremAmount/{customerId}")
	public List<Integer> getInsurancePremiumMount(@PathVariable int customerId) {
		List<Integer> policyCount = insuranceres.getInsurancePremiumAmount(customerId);
		return policyCount;
	}

	@GetMapping("/policyPremRealtion/{customerId}")
	public List<String> getInsuranceAppRelation(@PathVariable int customerId) {
		List<String> policyCount = insuranceres.getApplicantRelation(customerId);
		return policyCount;
	}

	@GetMapping("/policySchedule")
	public List<InsurancePolicySchedule> getAllPolicySchedule() {
		return insuranceres.ListAllPolicySchedules();
	}

	@GetMapping("/policySchedule/{id}")
	public List<InsurancePolicySchedule> listAllPolicySchedules(@PathVariable Integer id) {
		return insuranceres.ListAllPolicySchedulesById(id);
	}

	@PostMapping("/saveUserData")
	@ResponseBody
	public Long saveUserData(@RequestParam("username") String userName, @RequestParam("password") String password) {
		return insuranceres.saveUserData(userName, password);

	}

	@PostMapping("/saveCustomerData")
	@ResponseBody
	public String saveCustomerData(@RequestBody CustomerData customerData, Model model) {
		customerData.setCust_status("Active");
		// Set the last updated date and user
		customerData.setCust_luudate(new Date(Calendar.getInstance().getTime().getTime())); // Current timestamp
		customerData.setCust_luuser(1);
		customerData.setCust_user_id(2);
		// replace withint userId= (int)sessionGetAttribute("userId");
		System.out.println("Received customer_userId: " + customerData.getCust_user_id());

		int userId = (int) session.getAttribute("userId");
		int customerId = insuranceres.getCustIdByUserId(userId);

		model.addAttribute("customerId", customerId);
		model.addAttribute("userId", userId);
		customerData.setCust_user_id((long) session.getAttribute("userId"));
		// Set a default value for cust_cdate (assuming it's a Date field)
		customerData.setCust_cdate(new Date(Calendar.getInstance().getTime().getTime())); // Current timestamp
		System.out.println("Received customer data: " + customerData);
		insuranceres.saveCustomerData(customerData);
		return "Customer data saved successfully";
	}

	@RequestMapping(value = "/Customers", method = RequestMethod.GET)

	public List<CustomerData> getAllCustomers() {
		Long id = (Long) session.getAttribute("userId");
		System.out.println("customers");
		return insuranceres.getAllCustomers();
	}

	@RequestMapping(value = "/UpdateCustomers", method = RequestMethod.POST)

	public String UpdateCustomers(@RequestBody List<CustomerData> updatedCustomerData) {

		for (CustomerData customerData : updatedCustomerData) {
			customerData.setCust_status("Active");

			// Convert java.util.Date to java.sql.Date
			java.util.Date now = new java.util.Date();
			customerData.setCust_luudate(new Date(now.getTime()));
			customerData.setCust_luuser(1);

			// Set a default value for cust_cdate as SQL Date (assuming it's a Date field)
			customerData.setCust_cdate(new Date(now.getTime()));

		}
		String check = insuranceres.updateCustomersData(updatedCustomerData);
		return check;
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public List<UserData> getAllUsers() {

		System.out.println("users");

		UserDataList = insuranceres.getAllUsers();

		return UserDataList;
	}

	@RequestMapping(value = "/UserLogin", method = RequestMethod.POST)

	public String userCredinitial(@RequestParam("username") String userName,
			@RequestParam("password") String password) {

		UserDataList = insuranceres.getAllUsers();
		boolean b = insuranceres.userChecking(userName, password, UserDataList);
		if (b) {
			return "1";
		}

		System.out.println("customers");

		return "-1";
	}

	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {
		String email = to_mail;
		session.setAttribute("email", email);
		// storing generated otp
		int OTP = insuranceres.sendmail(to_mail);
		System.out.println(to_mail + "email here");
		System.out.println(OTP + "otp here");

		LocalTime currentTime = LocalTime.now();
		session.setAttribute("time", currentTime.plusMinutes(5));
		session.setAttribute("OTP", OTP);

		return "Email Sent Successfully";

	}

	@PostMapping(value = "/validateOTP")
	public String validateOTP(@RequestParam("otp") String otp, Model model) {
		model.addAttribute("to", "");
		int OTP = Integer.parseInt(otp);
		ModelAndView mav = new ModelAndView();
		int originalOtp = (Integer) session.getAttribute("OTP");
		String email = (String) session.getAttribute("email");

		LocalTime time = (LocalTime) session.getAttribute("time");
		int comp = time.compareTo(LocalTime.now());
		// checking the otp sent by the user if true returning reset page else need to
		// stay in the same page with error
		// msg
		if (originalOtp == OTP && comp > 0) {
			mav.setViewName("reset");
			mav.addObject("email", email);
			return "otp Match";
		}
		if (comp < 0)
			return "OTP expired, please try again..";
		else
			return "Invalid OTP, please try again..";

	}

	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		System.out.println(email + " " + pwd + " " + cnfpwd);
		int x = insuranceres.resetpwd(email, pwd, cnfpwd);
		if (x > 0)
			return "password Changed";
		else
			return "pasword not match";

	}

	@RequestMapping(value = "/claimbills", method = RequestMethod.POST)
	public String claimData(@RequestParam("file[]") MultipartFile[] files,
			@RequestParam("documentTitle") String[] documentNames, @RequestParam("claimAmount") String[] claimAmount,
			Claim claim, ClaimApplication application) {

		insuranceres.addClaimApplication(application);
		insuranceres.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested());
		System.out.println(claim.getClamIplcId());
		Claim clm_id = insuranceres.getClaimByid(claim.getClamIplcId());
		int cid = clm_id.getClamId();

		String uploadDir = "src/main/resources/static/file";

		try {
			// Create the target directory if it doesn't exist
			Files.createDirectories(Paths.get(uploadDir));
			int i = 0;

			for (MultipartFile file : files) {
				// Get the original file name
				System.out.println("start");
				String fileName = StringUtils.cleanPath(file.getOriginalFilename());

				// Create the target file path within the directory
				Path targetLocation = Paths.get(uploadDir).resolve(fileName);

				// Copy the file to the target location
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

				String fullPath = fileName;
				ClaimBills bill = new ClaimBills();
				bill.setClbl_document_path(fullPath);
				bill.setClbl_document_title(documentNames[i]);
				bill.setClbl_claim_amount(Double.parseDouble(claimAmount[i]));
				bill.setClam_id(cid);
				insuranceres.addClaimBills(bill);
				System.out.println("end");

			}

			// After successfully storing all files, you can redirect to a success page or return a response accordingly
			return "Success";
		} catch (IOException ex) {
			ex.printStackTrace();

		}

		return "Success";
	}

	@GetMapping(value = "/getFamilyMembers")
	public List<String> getFamily(@RequestParam("policy") int id) {
		List<String> members = insuranceres.getFamilyByPolicy(id);
		return members;
	}

	@GetMapping(value = "/getAllClaims")
	public ArrayList<Claim> getAllClaims() {
		ArrayList<Claim> li = (ArrayList<Claim>) insuranceres.getAllClaims();
		System.out.println(li.size());
		return li;
	}

	@PostMapping(value = "/viewClaim")
	public Claim getClaimById(@RequestParam("clamId") int clamId) {
		Claim cl = insuranceres.getClaimByid(clamId);
		return cl;
	}

	@GetMapping(value = "/getFilteredClaims")
	public ArrayList<Claim> getFilteredClaims(@RequestParam("status") String status) {
		ArrayList<Claim> li = (ArrayList<Claim>) insuranceres.getFilteredClaims(status);
		System.out.println(li.size());
		return li;
	}

	@GetMapping(value = "/getrequired")
	public List<ReUpload> getRequiredUploads(@RequestParam("claimid") int id) {
		return insuranceres.getAllReUploads(id);

	}

	@GetMapping(value = "/getAllClaimBills")
	public List<ClaimBills> getAllClaimBills() {
		return insuranceres.getAllClaimBills();

	}

	@PostMapping(value = "/adduploads")
	public void addUploads(@RequestParam("claimId") int claimId, MultipartHttpServletRequest request) {

		int index = 1;

		List<ReUpload> list = insuranceres.getAllReUploads(claimId);
		List<Uploads> list2 = insuranceres.getAllUploads(claimId);

		if (list2.size() > 0) {

			index = list2.get(list2.size() - 1).getReUploadId();
		}
		for (ReUpload upload : list) {
			if (upload.getClaimId() == claimId) {
				String name = upload.getName();
				System.out.println(claimId);
				MultipartFile file = request.getFile(name);
				if (file != null && !file.isEmpty()) {
					System.out.println(name);
					if (upload.getType().equals("file")) {
						System.out.println("file");

						String uploadDir = "src/main/resources/static/file";
						try {
							Files.createDirectories(Paths.get(uploadDir));
							String fileName = StringUtils.cleanPath(file.getOriginalFilename());
							Path targetLocation = Paths.get(uploadDir).resolve(fileName);
							Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
							String fullPath = targetLocation.toAbsolutePath().toString();
							Uploads up = new Uploads();
							up.setUploadId(index);
							up.setReUploadId(upload.getUploadId());
							up.setClaimId(claimId);
							up.setData(fullPath);
							up.setType("file");

							insuranceres.addUploads(up);
							// after uploaded required document then update status
							insuranceres.updateStatus(claimId);
						} catch (IOException ex) {
							ex.printStackTrace();
						}
					} else {

						Uploads up = new Uploads();

						up.setUploadId(index);
						up.setReUploadId(upload.getUploadId());
						up.setClaimId(claimId);
						up.setData(file.getOriginalFilename());
						up.setType("text");

						insuranceres.addUploads(up);
					}
				}
			}
		}
	}

}
