package com.spring.boot.jdbc.Customeroptions.repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.spring.boot.jdbc.Customeroptions.dao.InsuranceDAO;
import com.spring.boot.jdbc.Customeroptions.model.AuthUtils;
import com.spring.boot.jdbc.Customeroptions.model.Claim;
import com.spring.boot.jdbc.Customeroptions.model.ClaimApplication;
import com.spring.boot.jdbc.Customeroptions.model.ClaimBills;
import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.FamilyMedicalHistoryData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicySchedule;
import com.spring.boot.jdbc.Customeroptions.model.ReUpload;
import com.spring.boot.jdbc.Customeroptions.model.Uploads;
import com.spring.boot.jdbc.Customeroptions.model.UserData;
import com.spring.boot.jdbc.Customeroptions.model.UserLoginValidation;

import jakarta.servlet.http.HttpSession;

@Repository
public class InsuranceRepository {
	@Autowired
	private InsuranceDAO insurancedao;
	private HttpSession session;

	@Autowired
	public InsuranceRepository(InsuranceDAO insurancedao, HttpSession session) {
		this.insurancedao = insurancedao;
		this.session = session;
	}

	public int getInsurancePolicyCountForCustomer(int customerId) {
		return insurancedao.getInsurancePolicyCountForCustomer(customerId);
	}

	public int getInsurancePolicyCountForFamily(int customerId) {
		return insurancedao.getInsurancePolicyCountForFamily(customerId);
	}

	public int getAllActivecount() {
		int l1 = insurancedao.getAllActivecountList();
		return l1;
	}

	public int getInsurancePolicySum(int customerId) {
		return insurancedao.getInsuranceSum(customerId);
	}

	public List<Date> getAllInsuranceDates(int customerId) {
		List<Date> l1 = insurancedao.getInsuranceDates(customerId);
		return l1;
	}

	public List<Date> getAllInsuranceEXPDates(int customerId) {
		List<Date> l2 = insurancedao.getInsuranceEXPDates(customerId);
		return l2;
	}

	public List<Integer> getInsurancePremiumAmount(int customerId) {
		List<Integer> l3 = insurancedao.getInsurancePremium(customerId);
		return l3;
	}

	public List<String> getApplicantName(int customerId) {
		List<String> l4 = insurancedao.getApplicantName(customerId);
		return l4;
	}

	public List<String> getApplicantRelation(int customerId) {
		List<String> l5 = insurancedao.getApplicantRelation(customerId);
		return l5;
	}

	public List<InsurancePolicySchedule> ListAllPolicySchedules() {
		List<InsurancePolicySchedule> s = insurancedao.getAllSchedule();
		return s;
	}

	public List<InsurancePolicySchedule> ListAllPolicySchedulesById(int id) {
		List<InsurancePolicySchedule> s = insurancedao.getAllScheduleById(id);
		return s;
	}

	public Long saveUserData(String userName, String password) {

		long id = insurancedao.saveUserData(userName, password);
		return id;
	}

	public void saveCustomerData(CustomerData customerData) {

		insurancedao.saveCustomerData(customerData);

	}

	public void saveFamilyMedicalHistory(FamilyMedicalHistoryData data) {
		insurancedao.saveFamilyMedicalHistoryData(data);

	}

	public List<CustomerData> getAllCustomers() {

		return insurancedao.getAllCustomersFromDao();

	}

	public List<UserData> getAllUsers() {

		return insurancedao.getAllUsersFromDao();
	}

	public List<FamilyMedicalHistoryData> getFamilyMedicalData() {

		return insurancedao.getFamilyMedicalData();
	}

	public String uploadFile(MultipartFile file) {

		return insurancedao.uploadFileToDao(file);
	}

	public List<String> getPdfFileNames() {
		// TODO Auto-generated method stub
		return insurancedao.getPdfFileNames();
	}

	public int sendmail(String to_mail) {
		String to = to_mail;
		String subject = "Password Reset";

		int OTP = generateOTP();
		String body = "The OTP for the Password Reset: " + OTP;
		sendEmail(to, subject, body);

		return OTP;
	}

	private static void sendEmail(String to, String subject, String body) {
		String host = "smtp.gmail.com";
		int port = 587;
		String username = "avengersbtrs@gmail.com";
		String password = "urpr twig ffeb uqlx";

		// Set properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);

		// Create session
		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// Create message
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);
			message.setText(body);
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	private static int generateOTP() {
		Random random = new Random();
		int randomNumber = 100000 + random.nextInt(900000);

		return randomNumber;
	}

	public int resetpwd(String email, String pwd, String cnfpwd) {
		if (pwd.equals(cnfpwd))
			return insurancedao.resetpwd(email, pwd);
		else
			return 0;
	}

	public String updateCustomersData(List<CustomerData> updatedCustomerData) {

		insurancedao.updateCustomersData(updatedCustomerData);

		return "updated Succesfully";
	}

	public String UpdateFamilyMedicalHistory(List<FamilyMedicalHistoryData> updatedFamilyMedicalHistoryData) {

		insurancedao.updateFamilyMedicalHistory(updatedFamilyMedicalHistoryData);

		return "updated succesfully";
	}

	public boolean userChecking(String userName, String password, List<UserData> userDataList) {
		for (UserData userData : userDataList) {

			if (userName.equals(userData.getUserName()) && password.equals(userData.getUserPwd())) {
				System.out.println(userData.getUserPwd());
				System.out.println(userData.getUserName());

				session.setAttribute("userId", userData.getUserId());

				String key = AuthUtils.generateKey();
				session.setAttribute("key", key);

				Long userId = userData.getUserId();

				UserLoginValidation user = insurancedao.getLoginTimeRange(userId);

				java.util.Date currentDate = new java.util.Date(); // Use java.util.Date

				// Check if the current date and time falls within the login time range
				// Format the current date to match the login date format
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String formattedCurrentDate = dateFormat.format(currentDate);

				// Get the login time range as Timestamp (java.sql.Timestamp)
				Timestamp loginTimeFrom = new Timestamp(user.getLoginTimeFrom().getTime());
				Timestamp loginTimeTo = new Timestamp(user.getLoginTimeTo().getTime());

				System.out.println("current Date: " + formattedCurrentDate);
				System.out.println("loginDate from Date: " + loginTimeFrom);
				System.out.println("loginDate to Date: " + loginTimeTo);

				if (formattedCurrentDate.compareTo(loginTimeFrom.toString()) >= 0
						&& formattedCurrentDate.compareTo(loginTimeTo.toString()) <= 0) {
					// Your code here

					System.out.println("I am inside time checking");

					System.out.println("Time checking");
					return true;
				}
			}
		}
		return false;
	}

	public Claim getClaimByid(int clamIplcId) {

		return insurancedao.getClaimByid(clamIplcId);
	}

	public void addClaimBills(ClaimBills bill) {
		insurancedao.addClaimBills(bill);

	}

	public void addClaimApplication(ClaimApplication application) {
		insurancedao.addClaimApplication(application);

	}

	public void addClaim(int clamIplcId, double claimAmountRequested) {
		insurancedao.addClaim(clamIplcId, claimAmountRequested);

	}

	public ArrayList<Claim> getFilteredClaims(String status) {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) insurancedao.getFilteredClaims(status);
	}

	public ArrayList<Claim> getAllClaims() {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) insurancedao.getAllClaims();
	}

	public List<String> getFamilyByPolicy(int id) {
		List<InsurancePolicyCoverageMembers> members = insurancedao.getPoliMem();
		List<String> names = new ArrayList<>();
		for (InsurancePolicyCoverageMembers mem : members) {
			if (mem.getIplcId() == id) {
				names.add(mem.getIpcmMemberName());
			}
		}

		return names;
	}

	public int getCustIdByUserId(int userId) {
		return insurancedao.getCustIdByUserId(userId);

	}

	public List<ReUpload> getAllReUploads(int id) {

		return insurancedao.getAllReUploads(id);
	}

	public List<Uploads> getAllUploads(int claimId) {
		return insurancedao.getAllUploads(claimId);
	}

	public void addUploads(Uploads up) {
		insurancedao.addUploads(up);
	}

	public List<ClaimBills> getAllClaimBills() {
		// TODO Auto-generated method stub
		return insurancedao.getAllClaimBills();
	}

	public void updateStatus(int claimId) {
		insurancedao.updateStatus(claimId);

	}

}
