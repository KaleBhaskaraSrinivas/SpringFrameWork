package com.spring.boot.jdbc.Customeroptions.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.boot.jdbc.Customeroptions.dao.InterfaceInsurancePolicyandPackageDAO;
import com.spring.boot.jdbc.Customeroptions.model.Faq;
import com.spring.boot.jdbc.Customeroptions.model.FormData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePackages;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicy;

@Repository
public class InsurancePackageAndPolicy {
	@Autowired
	InterfaceInsurancePolicyandPackageDAO idao;


	public List<InsurancePolicy> getAllInsurancePolicies() {
		// TODO Auto-generated method stub
		return idao.getAllInsurancePolicies();
	}
	

	public List<Faq> getAllFAQS() {
		// TODO Auto-generated method stub
		return idao.getAllFAQS();
	}


	
	public List<InsurancePolicy> getCustomerInsurancePolicy(int cust) {
		// TODO Auto-generated method stub
		return idao.getCustomerInsurancePolicy(cust);
	}



	public List<InsurancePackages> getInsurancePackages() {
		// TODO Auto-generated method stub
		return idao.getInsurancePackages();
	}
	
	public void addCustomer(FormData loan) {
		// TODO Auto-generated method stub
		idao.addCustomer(loan);
	}

	public List<Faq> getGeneralFAQS() {
		// TODO Auto-generated method stub
		return idao.getGeneralFAQS();
	}


	
	public List<Faq> getCoverageandBenefitsFAQS() {
		// TODO Auto-generated method stub
		return idao.getCoverageandBenefitsFAQS();
	}
}
