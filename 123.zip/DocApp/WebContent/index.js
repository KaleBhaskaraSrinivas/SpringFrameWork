$(document).ready(function() {
    $("#register-form-content").submit(function(event) {
        event.preventDefault(); 

       
        var regUsername = $("#reg-username").val();
        var regPassword = $("#reg-password").val();
        var confirmPassword = $("#confirm-password").val();

        
        if (regUsername === "") {
            alert("Username is required");
            return false;
        }

        if (regPassword === "") {
            alert("Password is required");
            return false;
        }

        if (confirmPassword === "") {
            alert("Confirm Password is required");
            return false;
        }

        if (regPassword !== confirmPassword) {
            alert("Passwords do not match");
            return false;
        }

       
        alert("Registration successful!");
       
    });
});
