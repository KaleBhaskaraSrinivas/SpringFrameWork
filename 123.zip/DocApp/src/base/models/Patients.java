package base.models;
public class Patients {
    private int patientid;
    private String patientname;
	private int patientage;
    private String patientgender;
    private int patientmobile;
    public Patients() {
    }
    public Patients(String patientname, int patientage, String patientgender, int patientmobile) {
		super();
		this.patientname = patientname;
		this.patientage = patientage;
		this.patientgender = patientgender;
		this.patientmobile = patientmobile;
	}
    public int getPatientId() {
        return patientid;
    }
    public void setId(int patientid) {
        this.patientid = patientid;
    }
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public int getPatientage() {
		return patientage;
	}
	public void setPatientage(int patientage) {
		this.patientage = patientage;
	}
	public String getPatientgender() {
		return patientgender;
	}
	public void setPatientgender(String patientgender) {
		this.patientgender = patientgender;
	}
	public int getPatientmobile() {
		return patientmobile;
	}
	public void setPatientmobile(int patientmobile) {
		this.patientmobile = patientmobile;
	}
}
