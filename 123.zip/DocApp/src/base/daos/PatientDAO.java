package base.daos;

import java.util.ArrayList;

import base.models.Patients;

public interface PatientDAO {
	public ArrayList<Patients> getAllUsers();

	public Patients getPatientId(String patientid);
	//public void addpatient(Patients patient);

	public Object addpatient(String name, int age, String gender, int mobile);
	

}
