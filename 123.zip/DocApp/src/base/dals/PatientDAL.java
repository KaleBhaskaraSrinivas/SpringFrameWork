package base.dals;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import java.util.ArrayList;
import base.daos.PatientDAO;
import base.models.Patients;

public class PatientDAL implements PatientDAO {
	private static ArrayList<Patients> patient = new ArrayList<>();
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Ap05cf3766";
	public PatientDAL() {
		
		try {
			Class.forName("org.postgresql.Driver");
			

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 

	}

	@Override
	public ArrayList<Patients> getAllUsers() {
		return patient;
	}

	@Override
	public Patients getPatientId(String patientid) {
		return patient.get(Integer.parseInt(patientid) - 1);
	}

	

	@Override
	public Object addpatient(String name, int age, String gender, int mobile) {
		// TODO Auto-generated method stub
		try (Connection connection = DriverManager.getConnection(url, username, password);
	             PreparedStatement statement = connection.prepareStatement(
	                     "INSERT INTO patients_venu (patientname, patientage, patientgender, patientmobile) VALUES (?, ?, ?, ?)")) {

	            statement.setString(1,name );
	            statement.setInt(2, age);
	            statement.setString(3, gender);
	            statement.setInt(4, mobile);

	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		
		return null;
	}

}






