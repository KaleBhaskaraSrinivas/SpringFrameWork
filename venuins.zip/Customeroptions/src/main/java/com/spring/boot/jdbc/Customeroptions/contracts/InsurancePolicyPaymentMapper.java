package com.spring.boot.jdbc.Customeroptions.contracts;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyPayment;

public class InsurancePolicyPaymentMapper implements RowMapper<InsurancePolicyPayment> {

    @Override
    public InsurancePolicyPayment mapRow(ResultSet rs, int rowNum) throws SQLException {
        InsurancePolicyPayment payment = new InsurancePolicyPayment();

        // Map the columns from the ResultSet to the fields of the InsurancePolicyPayment object
        payment.setInpp_id(rs.getInt("inpp_id"));
        payment.setPolicyId(rs.getInt("inpp_iplc_id"));
        payment.setTransactionId(rs.getString("inpp_trans_id"));
        payment.setAmount(rs.getDouble("inpp_amount"));
        payment.setPaymentMode(rs.getString("inpp_paymode"));
        payment.setTransDate(rs.getDate("inpp_date"));

        return payment;
    }
}
