package com.spring.boot.jdbc.Customeroptions.dao;

import java.util.List;

import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.Faq;
import com.spring.boot.jdbc.Customeroptions.model.FormData;
import com.spring.boot.jdbc.Customeroptions.model.HealthInsuranceApplication;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePackages;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicy;


public interface InterfaceInsurancePolicyandPackageDAO {
List<InsurancePolicy> getAllInsurancePolicies();
	
	List<Faq> getAllFAQS();

	List<InsurancePolicy> getCustomerInsurancePolicy(int cust);

	List<InsurancePackages> getInsurancePackages();

	void addCustomer(FormData loan);

	List<Faq> getGeneralFAQS();

	List<Faq> getCoverageandBenefitsFAQS();

}
