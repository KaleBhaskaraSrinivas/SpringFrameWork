package com.spring.boot.jdbc.Customeroptions.dao;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.spring.boot.jdbc.Customeroptions.contracts.ClaimMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.CustomerDataRowMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.FamilyMedicalHistoryDataRowMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.InsurancePolicyScheduleRowMapper;
import com.spring.boot.jdbc.Customeroptions.contracts.*;
import com.spring.boot.jdbc.Customeroptions.contracts.UsersDataRowMapper;
import com.spring.boot.jdbc.Customeroptions.model.Claim;
import com.spring.boot.jdbc.Customeroptions.model.ClaimApplication;
import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.FamilyMedicalHistoryData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicySchedule;
import com.spring.boot.jdbc.Customeroptions.model.ReUpload;
import com.spring.boot.jdbc.Customeroptions.model.Uploads;
import com.spring.boot.jdbc.Customeroptions.model.UserData;
import com.spring.boot.jdbc.Customeroptions.model.UserLoginValidation;

import jakarta.servlet.http.HttpSession;

@Component
public class InsuranceDAO implements InterfaceInsuranceDAO {
	JdbcTemplate jdbcTemplate;
	HttpSession session;

	@Autowired
	public InsuranceDAO(DataSource dataSource, HttpSession session) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		this.session = session;
	}

	private final String SQL_POLICY_COUNT = "SELECT COUNT(*) FROM InsurancePolicies1 WHERE iplc_cust_id = ?";
	private final String SQL_POLICY_FAMILYCOUNT = "SELECT iplc_nom_insured FROM InsurancePolicies1 WHERE iplc_cust_id = ?";
	private final String SQL_DISPLAY_ACTIVECOUNT = "SELECT COUNT(*) FROM InsurancePolicies1 WHERE iplc_expdate > iplc_cdate";
	private final String SQL_POLICY_SUM = "select sum(iplc_sum_assured) from InsurancePolicies1 where iplc_cust_id=?";
	private final String SQL_POLICY_DATE = "select iplc_applicable_date from InsurancePolicies1 where iplc_cust_id=?";
	private final String SQL_POLICY_EXDATE = "select iplc_expdate from InsurancePolicies1 where iplc_cust_id=?";
	private final String SQL_POLICY_PREAMOUNT = "select iplc_yrly_prem_amount from InsurancePolicies1 where iplc_cust_id=?";
	private final String SQL_POLICY_NAME = "select iplc_applicant_name from InsurancePolicies1 where iplc_cust_id=?";
	private final String SQL_POLICY_RELATION = "select iplc_applicant_relation from InsurancePolicies1 where iplc_cust_id=?";
	private String SQL_GET_CLAIMS = "select * from  _Claims";
	private String SQL_GET_CLAIM_BY_ID = "select * from  _Claims where clam_id=?";
	private String SQL_INSERT_CLAIM = "insert into _Claims(clam_source,clam_type,clam_date,clam_amount_requested,clam_iplc_id) values(?,?,?,?,?)";
	private String SQL_INSERT_CLAIMBill = "insert into Claim_bills(clam_id,clbl_document_title,clbl_document_path,clbl_claim_amount) values(?,?,?,?)";
	private String SQL_GET_FILTERED_CLAIMS = "select * from  _Claims where clam_status=?";

	@Override
	public int getInsurancePolicyCountForCustomer(int customerId) {
		// String SQL_POLICY_COUNT = "SELECT COUNT(*) FROM InsurancePolicies WHERE
		// iplc_cust_id = ?";
		return jdbcTemplate.queryForObject(SQL_POLICY_COUNT, Integer.class, customerId);
	}

	@Override
	public int getInsurancePolicyCountForFamily(int customerId) {
		// String SQL_POLICY_COUNT = "SELECT COUNT(*) FROM InsurancePolicies WHERE
		// iplc_cust_id = ?";
		return jdbcTemplate.queryForObject(SQL_POLICY_FAMILYCOUNT, Integer.class, customerId);
	}

	@Override
	public int getInsuranceSum(int customerId) {
		return jdbcTemplate.queryForObject(SQL_POLICY_SUM, Integer.class, customerId);
	}

	public int getAllActivecountList() {
		return jdbcTemplate.queryForObject(SQL_DISPLAY_ACTIVECOUNT, Integer.class);
	}

	@Override
	public List<InsurancePolicySchedule> getAllSchedule() {
		String sql = "SELECT * FROM insurancepolicyschedule ORDER BY iplc_date";
		return jdbcTemplate.query(sql, new InsurancePolicyScheduleRowMapper());
	}

	@Override
	public List<Integer> getInsurancePremium(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_PREAMOUNT, Integer.class, customerId);
	}

	@Override
	public List<Date> getInsuranceDates(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_DATE, Date.class, customerId);
	}

	@Override
	public List<Date> getInsuranceEXPDates(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_EXDATE, Date.class, customerId);
	}

	@Override
	public List<String> getApplicantName(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_NAME, String.class, customerId);
	}

	@Override
	public List<String> getApplicantRelation(int customerId) {
		return jdbcTemplate.queryForList(SQL_POLICY_RELATION, String.class, customerId);
	}

	public long saveUserData(String userName, String password) {

		java.util.Date currentDate = new java.util.Date(); // Use java.util.Date for the current date

		// Convert java.util.Date to java.sql.Date
		Date sqlCurrentDate = new Date(currentDate.getTime());

		// Set the userStatus as "active"
		String userStatus = "active";

		// Set the user type as "customer"
		String userType = "customer";

		String insertSql = "INSERT INTO Users (userName, userCDate, userPwd, userType, userStatus) "
				+ "VALUES (?, ?, ?, ?, ?)";

		return jdbcTemplate.update(insertSql, userName, sqlCurrentDate, password, userType, userStatus);
	}

	@Override
	public void saveCustomerData(CustomerData customerData) {
		String sql = "INSERT INTO Customers (cust_fname, cust_lname, cust_dob, cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, cust_luudate, cust_luuser,cust_user_id) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

		jdbcTemplate.update(sql, customerData.getCust_fname(), customerData.getCust_lname(), customerData.getCust_dob(),
				customerData.getCust_address(), String.valueOf(customerData.getCust_gender()),
				customerData.getCust_cdate(), customerData.getCust_aadhar(), customerData.getCust_status(),
				customerData.getCust_luudate(), customerData.getCust_luuser(), customerData.getCust_user_id());

	}

	public void saveFamilyMedicalHistoryData(FamilyMedicalHistoryData history) {
		String sql = "INSERT INTO FamilyMedicalHistory (mother_disease, grandmother_disease, father_disease, grandfather_disease, userid) "
				+ "VALUES (?, ?, ?, ?, ?)";

		jdbcTemplate.update(sql, history.getMotherDisease(), history.getGrandmotherDisease(),
				history.getFatherDisease(), history.getGrandfatherDisease(), history.getUserid());
	}

	public List<CustomerData> getAllCustomersFromDao() {

		return jdbcTemplate.query("select * from Customers", new CustomerDataRowMapper());

	}

	public List<UserData> getAllUsersFromDao() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from users", new UsersDataRowMapper());
	}

	public List<FamilyMedicalHistoryData> getFamilyMedicalData() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from FamilyMedicalHistory ", new FamilyMedicalHistoryDataRowMapper());

	}

	public String uploadFileToDao(MultipartFile file) {
		String uploadDir = "src/main/resources/static/file"; // Replace with the actual path on your server

		try {
			// Get the original file name
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());

			// Create the target directory if it doesn't exist
			Files.createDirectories(Paths.get(uploadDir));

			// Create the target file path within the directory
			Path targetLocation = Paths.get(uploadDir).resolve(fileName);

			// Copy the file to the target location
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

			String fullPath = targetLocation.toAbsolutePath().toString();
			Long userId = (Long) session.getAttribute("userId");

			Long customerId = (Long) session.getAttribute("customerId");

			uploadFileToDatabase(userId, customerId, fullPath, fileName);
			return fileName; // Retur the stored file name
		} catch (IOException ex) {
			System.out.println(ex);
			return null; // Return an error message or handle the exception as needed
		}
	}

	public void uploadFileToDatabase(Long userId, Long customerId, String fullPath, String fileName) {
		String sql = "INSERT INTO fileUploadData (userId, customerId, fullPath, fileName) VALUES (?, ?, ?, ?)";

		jdbcTemplate.update(sql, userId, customerId, fullPath, fileName);
	}

	public List<String> getPdfFileNames() {
		String uploadDir = "src/main/resources/static/file"; // Replace with the actual path on your server

		List<String> pdfFileNames = new ArrayList<>();
		File directory = new File(uploadDir);

		if (directory.exists() && directory.isDirectory()) {
			File[] files = directory.listFiles();

			if (files != null) {
				for (File file : files) {
					if (file.isFile() && file.getName().toLowerCase().endsWith(".png")) {
						pdfFileNames.add(file.getName());
					}
				}
			}
		}
		System.out.println(pdfFileNames);
		return pdfFileNames;
	}

	public int resetpwd(String email, String pwd) {
		int userId1 = (int) session.getAttribute("userId");

		String sql = "UPDATE updatePasswordTable SET username = ?, password = ? WHERE userId = ?";
		return jdbcTemplate.update(sql, email, pwd, 1);
	}

	public void updateCustomersData(List<CustomerData> updatedCustomerData) {
		for (CustomerData customer : updatedCustomerData) {
			// Step 1: Delete existing record with the same cust_id
			String deleteSql = "DELETE FROM Customers WHERE cust_id = ?";
			jdbcTemplate.update(deleteSql, customer.getCust_id());

			// Step 2: Insert the updated customer data
			String insertSql = "INSERT INTO Customers (cust_id, cust_fname, cust_lname, cust_dob, "
					+ "cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, "
					+ "cust_luudate, cust_luuser) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			jdbcTemplate.update(insertSql, customer.getCust_id(), customer.getCust_fname(), customer.getCust_lname(),
					customer.getCust_dob(), customer.getCust_address(), customer.getCust_gender(),
					customer.getCust_cdate(), customer.getCust_aadhar(), customer.getCust_status(),
					customer.getCust_luudate(), customer.getCust_luuser());
		}
	}

	public void updateFamilyMedicalHistory(List<FamilyMedicalHistoryData> updatedFamilyMedicalHistoryData) {
		// Step 1: Delete all existing records for the given userid
		Long userid = updatedFamilyMedicalHistoryData.get(0).getUserid(); // Assuming the list is not empty
		String deleteSql = "DELETE FROM FamilyMedicalHistory WHERE userid = ?";
		jdbcTemplate.update(deleteSql, userid);

		// Step 2: Insert new data into the FamilyMedicalHistory table
		for (FamilyMedicalHistoryData data : updatedFamilyMedicalHistoryData) {
			String insertSql = "INSERT INTO FamilyMedicalHistory (userid, mother_disease, "
					+ "grandmother_disease, father_disease, grandfather_disease) VALUES (?, ?, ?, ?, ?)";

			jdbcTemplate.update(insertSql, data.getUserid(), data.getMotherDisease(), data.getGrandmotherDisease(),
					data.getFatherDisease(), data.getGrandfatherDisease());
		}
	}

	public UserLoginValidation getLoginTimeRange(Long userId) {
		String sql = "SELECT * FROM user_login_validation WHERE user_id = ?";

		return jdbcTemplate.queryForObject(sql, new Object[] { userId }, new UserLoginValidationRowMapper());
	}

	@Override
	public List<InsurancePolicySchedule> getAllScheduleById(int id) {
		String sql = "select * from InsurancePolicySchedule where iplc_id=?";
		return jdbcTemplate.query(sql, new InsurancePolicyScheduleRowMapper(), new Object[] { id });
	}

	public Claim getClaimByid(int clamIplcId) {
		return jdbcTemplate.queryForObject(SQL_GET_CLAIM_BY_ID, new Object[] { clamIplcId }, new ClaimMapper());
	}

	public void addClaimBills(String originalFilename, String filePath, int cid, int i) {
		System.out.println("brooo");
		jdbcTemplate.update(SQL_INSERT_CLAIMBill, originalFilename, filePath, i);

	}

	public void addClaimApplication(ClaimApplication application) {
		System.out.println(application.getMemberIndex() + 1);
		String query = "insert into insurance_claim(policy_id,member_index,relation,joined_date,patient_name,date_of_birth,gender,contact_number,address,disease,diagnosis,treatment,claimAmount,hosp_name) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] values = { application.getClamIplcId(), application.getMemberIndex(), application.getRelation(),
				application.getJoinedDate(), application.getPatientName(), application.getDateOfBirth(),
				application.getGender(), application.getContactNumber(), application.getAddress(),
				application.getDisease(), application.getDiagnosis(), application.getTreatment(),
				application.getClaimAmountRequested(), "Service" };
		jdbcTemplate.update(query, values);

	}

	public void addClaim(int clamIplcId, double claimAmountRequested) {
		LocalDate currentDate = LocalDate.now();
		java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
		jdbcTemplate.update(SQL_INSERT_CLAIM, "INDI", "IND", sqlDate, claimAmountRequested, clamIplcId);

	}

	@Override
	public ArrayList<Claim> getAllClaims() {
		return (ArrayList<Claim>) jdbcTemplate.query(SQL_GET_CLAIMS, new ClaimMapper());
	}

	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) jdbcTemplate.query(SQL_GET_FILTERED_CLAIMS, new Object[] { status },
				new ClaimMapper());
	}

	@Override
	public Claim getClaimById(int clamId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject(SQL_GET_CLAIM_BY_ID, new Object[] { clamId }, new ClaimMapper());
	}
	@Override
	public Claim getClaimById1(int clamId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject(SQL_GET_CLAIM_BY_ID, new Object[] { clamId }, new ClaimMapper());
	}
	@Override
	public List<InsurancePolicyCoverageMembers> getPoliMem() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(
				"select iplc_id,ipcm_mindex,ipcm_membername,ipcm_relation, ipcm_dob, ipcm_gender,ipcm_healthhistory from insurancepolicycoveragemembers",
				new InsurancePolicyCoverageMemberMapper());
	}
	@Override
	public int  getCustIdByUserId(int userId) {
		String sql = "SELECT custId FROM Customer WHERE userId = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{userId}, Integer.class);	
	}
	@Override
	public void addRequiredUploads(ReUpload upload) {
		String query = "insert into reuploads(claimId,name,type,Status,description) values(?,?,?,?,?)";
		Object[] values = { upload.getClaimId(), upload.getName(), upload.getType(), upload.getStatus(),
				upload.getDescription() };
		jdbcTemplate.update(query, values);
	}

	@Override
	public List<ReUpload> getAllReUploads(int id) {

		return jdbcTemplate.query("select * from reuploads where claimId="+id, new ReUploadRowMapper());
	}

	@Override
	public void addUploads(Uploads up) {

		System.out.println("jdbc");
		String query = "insert into uploads(uploadId,reuploadId,claimId,data,type) values(?,?,?,?)";
		Object[] values = { up.getUploadId(), up.getReUploadId(), up.getClaimId(), up.getData(), up.getType() };
		jdbcTemplate.update(query, values);
	}

	@Override
	public List<Uploads> getAllUploads(int claimId) {
		
		return jdbcTemplate.query("select * from uploads where claimId="+claimId, new UploadsRowMapper());
	}

}
