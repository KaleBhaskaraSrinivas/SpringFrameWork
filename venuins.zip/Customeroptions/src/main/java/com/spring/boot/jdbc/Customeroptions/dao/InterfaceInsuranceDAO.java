package com.spring.boot.jdbc.Customeroptions.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.spring.boot.jdbc.Customeroptions.model.Claim;
import com.spring.boot.jdbc.Customeroptions.model.ClaimApplication;
import com.spring.boot.jdbc.Customeroptions.model.CustomerData;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.spring.boot.jdbc.Customeroptions.model.InsurancePolicySchedule;
import com.spring.boot.jdbc.Customeroptions.model.ReUpload;
import com.spring.boot.jdbc.Customeroptions.model.Uploads;
import com.spring.boot.jdbc.Customeroptions.model.UserData;
import com.spring.boot.jdbc.Customeroptions.model.UserLoginValidation;

public interface InterfaceInsuranceDAO {

	
	int getAllActivecountList();

	List<Integer> getInsurancePremium(int customerId);

	List<Date> getInsuranceDates(int customerId);

	List<Date> getInsuranceEXPDates(int customerId);

	// List<InsurancePolicy> getInsuranceDates(int customerId);

	int getInsuranceSum(int customerId);

	int getInsurancePolicyCountForCustomer(int customerId);

	List<String> getApplicantName(int customerId);

	List<String> getApplicantRelation(int customerId);

	List<InsurancePolicySchedule> getAllSchedule();
	 List<InsurancePolicySchedule> getAllScheduleById(int id);

	long saveUserData(String userName, String password);

	void saveCustomerData(CustomerData customerData);

	List<CustomerData> getAllCustomersFromDao();

	List<UserData> getAllUsersFromDao();

	List<String> getPdfFileNames();

	int resetpwd(String email, String pwd);

	void updateCustomersData(List<CustomerData> updatedCustomerData);
	int getInsurancePolicyCountForFamily(int customerId);

	public UserLoginValidation getLoginTimeRange(Long userId);
	public Claim getClaimByid(int clamIplcId);
	public void addClaimBills(String originalFilename, String filePath, int cid, int i);
	public void addClaimApplication(ClaimApplication application);
	public void addClaim(int clamIplcId, double claimAmountRequested);
	public ArrayList<Claim> getFilteredClaims(String status);
	public Claim getClaimById(int clamId);
	public ArrayList<Claim> getAllClaims();
	public Claim getClaimById1(int clamId);
	public List<InsurancePolicyCoverageMembers> getPoliMem();
	public int  getCustIdByUserId(int userId);
	public void addRequiredUploads(ReUpload upload);
	
	public List<ReUpload> getAllReUploads(int id);

	
	public void addUploads(Uploads up);

	
	public List<Uploads> getAllUploads(int claimId);

}
